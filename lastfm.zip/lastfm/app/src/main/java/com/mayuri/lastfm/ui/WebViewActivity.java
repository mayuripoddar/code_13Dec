package com.mayuri.lastfm.ui;

import android.os.Bundle;
import android.util.Log;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.appcompat.app.AppCompatActivity;
import com.mayuri.lastfm.R;

public class WebViewActivity extends AppCompatActivity {

    private WebView webView;
    private String urlData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);
        webView = findViewById(R.id.webView);
        Bundle bn = getIntent().getExtras();
        if (bn != null && bn.containsKey("urlData")) {
            urlData = bn.getString("urlData");
            Log.e("EM", ":::::::::::Url Data::::::::::");
            initialpageSetup();
        }


    }

    private void initialpageSetup() {

        webView.setWebChromeClient(new WebChromeClient());
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webView.requestFocus();
        webView.setClickable(true);
        webView.setFocusableInTouchMode(true);
        webView.setFocusable(true);
        webView.setScrollbarFadingEnabled(true);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        webView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
        // webView.addJavascriptInterface(new Service_QNA.WebAppInterface(mContext, rlFinishLayout, scroll_btm), "AndroidMsg");
        webView.setBackgroundColor(getResources().getColor(R.color.color_transparent));
        webView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
        webView.setScrollbarFadingEnabled(false);
        webView.loadUrl(urlData);
    }

}
